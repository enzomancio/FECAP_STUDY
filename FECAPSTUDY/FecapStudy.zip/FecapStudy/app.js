// ============ Missão 9: Interface gráfica (só lê controles e chama objetos) ============
const $ = id => document.getElementById(id);
let tt; const toast = m => { const t = $("toast"); t.textContent = m; t.className = "on"; clearTimeout(tt); tt = setTimeout(() => t.className = "", 3800); };

const admin = new Administrador(1, DADOS.admin.nome, DADOS.admin.email, DADOS.admin.senha, DADOS.admin.cargo);
const resp = new Responsavel(2, DADOS.responsavel.nome, DADOS.responsavel.email, DADOS.responsavel.senha, DADOS.responsavel.parentesco);
const aluno = new Discente(3, DADOS.discente.nome, DADOS.discente.email, DADOS.discente.senha, DADOS.discente.ra);
const meta = new MetaEstudo(DADOS.metaMinutosSemana);
resp.vincularDiscente(aluno, meta);
const catalogo = DADOS.disciplinas.map(d => new Disciplina(...d));
const trilha = new TrilhaEstudo(DADOS.trilhaTitulo, admin); catalogo.forEach(d => trilha.adicionarDisciplina(d));
const plano = new PlanoEstudo(); DADOS.plano.forEach(([dia, m]) => plano.adicionarItem(dia, m));
const cliente = new ClienteBackendEstudo(DADOS.urlBackend);
const notificadores = { email: new NotificadorEmail(toast), whatsapp: new NotificadorWhatsApp(toast), painel: new NotificadorPainel(toast) };
const servicoAlerta = new ServicoAlertaResponsavel();

const lista = (ul, itens, vazio) => { ul.replaceChildren(...(itens.length ? itens : [vazio]).map(t => Object.assign(document.createElement("li"), { textContent: t }))); };

function renderizar() {
  $("perfilD").textContent = aluno.gerarPainelResumo();
  $("perfilR").textContent = resp.gerarPainelResumo();
  $("xp").innerHTML = `${aluno.getXpTotal()} <small>XP</small>`;
  const p = meta.calcularPercentual();
  $("fill").style.width = p + "%"; $("barra").setAttribute("aria-valuenow", Math.round(p));
  $("metaTxt").textContent = `${meta.getMinutosCumpridos()} de ${meta.getMetaMinutosSemana()} min (${p.toFixed(0)}%)` + (meta.estaCumprida() ? " — meta cumprida!" : "");
  lista($("hist"), aluno.getHistorico().map(s => s.gerarFeedback()), "Nenhum estudo registrado ainda.");
  $("trilhaT").textContent = `${trilha.getTitulo()} — ${trilha.calcularCargaHorariaTotal()}h/semana`;
  lista($("trilha"), trilha.getDisciplinas().map(d => d.exibirResumo()), "");
  lista($("plano"), plano.listarItens(), "");
  $("planoTot").textContent = `Total planejado: ${plano.calcularTotalMinutos()} min`;
}

function ajustarCampos() {
  const m = $("mod").value;
  $("extraL").textContent = { Pomodoro: "Ciclos completos", Exercicios: "Acertos", Leitura: "Páginas lidas" }[m];
  $("boxTotal").classList.toggle("hide", m !== "Exercicios");
  $("boxResumo").classList.toggle("hide", m !== "Leitura");
}

function criarSessao() {
  const disc = catalogo[$("disc").selectedIndex], min = +$("min").value, ex = +$("extra").value;
  switch ($("mod").value) {
    case "Pomodoro": return new SessaoPomodoro(disc, min, ex);
    case "Exercicios": return new SessaoExercicios(disc, min, +$("total").value, Math.min(ex, +$("total").value));
    default: return new SessaoLeitura(disc, min, ex, $("resumo").checked);
  }
}

function setStatus(txt, erro) { $("status").textContent = txt; $("status").className = erro ? "erro" : ""; }

$("registrar").addEventListener("click", async () => {
  const sessao = criarSessao();
  if (!meta.registrarAvanco(sessao.getDuracaoMinutos())) return toast("Duração inválida: use de 1 a 480 minutos.");
  aluno.registrarEstudo(sessao); renderizar(); toast(sessao.gerarFeedback());
  try { await cliente.salvarSessao(aluno.getNome(), sessao); setStatus("Sessão gravada no backend ✔"); }
  catch { setStatus("Backend offline — a sessão ficou só na memória. Rode iniciar_backend.bat.", true); }
});

$("notificar").addEventListener("click", () => servicoAlerta.avaliarDiscente(aluno, meta, resp, notificadores[$("canal").value]));

$("carregar").addEventListener("click", async () => {
  try {
    const r = await cliente.listarSessoes(), itens = Array.isArray(r) ? r : (r.sessoes || []);
    lista($("srv"), itens.map(s => s.resumoFeedback || JSON.stringify(s)), "Nenhuma sessão salva no servidor.");
    setStatus(`${itens.length} sessão(ões) no servidor.`);
  } catch { setStatus("Não consegui falar com http://localhost:5080 — o backend está rodando?", true); }
});

$("mod").addEventListener("change", ajustarCampos);
$("disc").replaceChildren(...catalogo.map(d => Object.assign(document.createElement("option"), { textContent: d.getNome() })));
ajustarCampos(); renderizar();
cliente.status().then(() => setStatus("Backend conectado ✔")).catch(() => setStatus("Backend offline. Rode iniciar_backend.bat.", true));
