// ========== Missão 10: ClienteBackendEstudo (Dependência do backend C#) ==========
class ClienteBackendEstudo {
  #base;
  constructor(urlBase = "http://localhost:5080") { this.#base = urlBase; }
  async #req(rota, opcoes) {
    const r = await fetch(this.#base + rota, opcoes);
    if (!r.ok) throw new Error(`HTTP ${r.status} em ${rota}`);
    return r.json();
  }
  status() { return this.#req("/api/status"); }
  listarSessoes() { return this.#req("/api/sessoes"); }
  relatorio(nomeDiscente) { return this.#req(`/api/relatorio/${encodeURIComponent(nomeDiscente)}`); }
  salvarSessao(nomeDiscente, sessao) {
    return this.#req("/api/sessoes", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: sessao.paraJson(nomeDiscente),
    });
  }
}
