// ============================================================
//  SEUS DADOS — edite só este arquivo
// ============================================================
const DADOS = {
  urlBackend: "http://localhost:5080",
  discente:    { nome: "Enzo Mancio Vaz", ra: "25027739", email: "enzo.vaz@edu.fecap.br", senha: "Santosfc2026" },
  responsavel: { nome: "Camilla Cerqueira Guedes", parentesco: "Mãe", email: "camilla.guedes@gmail.com", senha: "1234" },
  admin:       { nome: "Adriano Valente", cargo: "Coordenação PI", email: "adriano.valente@fecap.br", senha: "1234" },
  metaMinutosSemana: 600,
  trilhaTitulo: "Trilha 2º Semestre ADS — Desenvolvimento",
  // [codigo, nome, categoria, horas semanais]
  disciplinas: [
    ["ADS201", "Programação Orientada a Objetos", "Computação", 4],
    ["ADS202", "Desenvolvimento Web",             "Computação", 4],
    ["ADS203", "Estrutura de Dados",              "Computação", 4],
    ["ADS204", "Banco de Dados",                  "Dados",      3],
  ],
  // [dia da semana, minutos planejados]
  plano: [["Segunda", 90], ["Terça", 60], ["Quarta", 90], ["Quinta", 60], ["Sexta", 120]],
};
if (typeof module !== "undefined") module.exports = DADOS;
