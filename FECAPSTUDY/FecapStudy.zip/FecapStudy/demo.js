// Teste das Missões 1–8 no terminal:  node demo.js
const D = require("./dados.js");
const L = require("./dominio.js");
const { Disciplina, MetaEstudo, Administrador, Responsavel, Discente, SessaoPomodoro, SessaoExercicios, SessaoLeitura,
  NotificadorEmail, NotificadorWhatsApp, TrilhaEstudo, PlanoEstudo, ServicoAlertaResponsavel } = L;

console.log("— Missão 1"); const ds = D.disciplinas.map(x => new Disciplina(...x)); ds.forEach(x => console.log(x.exibirResumo()));
console.log(new Disciplina("X", "Teste", "Teste", -4).exibirResumo());
console.log("— Missão 2"); const m = new MetaEstudo(100);
console.log(m.registrarAvanco(-20), m.registrarAvanco(900), m.getMinutosCumpridos(), m.registrarAvanco(60), m.calcularPercentual() + "%");
console.log("— Missão 3"); try { new L.Usuario(); } catch (e) { console.log("Bloqueado:", e.message); }
const adm = new Administrador(1, D.admin.nome, D.admin.email, D.admin.senha, D.admin.cargo);
const resp = new Responsavel(2, D.responsavel.nome, D.responsavel.email, D.responsavel.senha, D.responsavel.parentesco);
const al = new Discente(3, D.discente.nome, D.discente.email, D.discente.senha, D.discente.ra);
[adm, resp, al].forEach(u => console.log(u.obterTipoPerfil() + " ->", u.gerarPainelResumo()));
console.log("Senha certa?", al.autenticar(D.discente.senha), "| getter de senha existe?", typeof al.getSenha);
console.log("— Missão 4");
[new SessaoPomodoro(ds[0], 50, 2), new SessaoExercicios(ds[1], 30, 10, 8), new SessaoLeitura(ds[2], 40, 12, true)]
  .forEach(s => console.log(s.gerarFeedback()));
console.log("— Missão 5"); al.registrarEstudo(ds[0], 50); al.registrarEstudo(ds[1], 14, 15, 10);
al.registrarEstudo(new SessaoExercicios(ds[1], 30, 10, 8)); console.log("XP:", al.getXpTotal(), "| sessões:", al.getHistorico().length);
console.log("— Missão 6"); const sv = new ServicoAlertaResponsavel(); const meta = new MetaEstudo(D.metaMinutosSemana);
console.log(L.cumpreContrato(new NotificadorEmail(), L.INotificador), L.cumpreContrato(meta, L.IExportavelJson));
console.log("— Missão 7"); resp.vincularDiscente(al, meta); resp.vincularDiscente(al, meta);
const tr = new TrilhaEstudo(D.trilhaTitulo, adm); ds.forEach(x => tr.adicionarDisciplina(x));
console.log("Discentes:", resp.getDiscentes().length, "| carga total:", tr.calcularCargaHorariaTotal() + "h");
console.log("— Missão 8"); const pl = new PlanoEstudo(); D.plano.forEach(([d, mi]) => pl.adicionarItem(d, mi));
console.log(pl.listarItens(), pl.calcularTotalMinutos() + " min");
meta.registrarAvanco(300); sv.avaliarDiscente(al, meta, resp, new NotificadorEmail());
meta.registrarAvanco(300); sv.avaliarDiscente(al, meta, resp, new NotificadorWhatsApp());
