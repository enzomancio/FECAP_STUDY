// ================= DOMÍNIO POO — Missões 1 a 8 =================

// Contratos (interfaces) — em JS, validados por duck typing (Missão 6)
const INotificador = ["obterCanal", "enviarAlerta"];
const IExportavelJson = ["paraJson"];
function cumpreContrato(obj, contrato) { return contrato.every(m => typeof obj[m] === "function"); }

// ---------- Missão 1: Abstração, Classe e Objeto ----------
class Disciplina {
  #codigo; #nome; #categoria; #horas;
  constructor(codigo, nome, categoria, horas) {
    this.#codigo = codigo; this.#nome = nome; this.#categoria = categoria;
    this.#horas = Number.isFinite(horas) && horas > 0 ? horas : 2;
  }
  getCodigo() { return this.#codigo; }
  getNome() { return this.#nome; }
  getCategoria() { return this.#categoria; }
  getCargaHorariaSemanalHoras() { return this.#horas; }
  calcularCargaEmMinutos() { return this.#horas * 60; }
  exibirResumo() {
    return `[${this.#codigo}] ${this.#nome} (${this.#categoria}) — ${this.#horas}h/semana (${this.calcularCargaEmMinutos()} min)`;
  }
}

// ---------- Missão 2: Encapsulamento ----------
class MetaEstudo {
  #meta = 30; #cumpridos = 0;
  constructor(metaMinutosSemana) { this.redefinirMeta(metaMinutosSemana); }
  redefinirMeta(nova) { this.#meta = Math.min(3000, Math.max(30, Math.trunc(nova) || 30)); }
  registrarAvanco(minutos) {
    if (!Number.isInteger(minutos) || minutos <= 0 || minutos > 480) return false;
    this.#cumpridos += minutos; return true;
  }
  getMetaMinutosSemana() { return this.#meta; }
  getMinutosCumpridos() { return this.#cumpridos; }
  calcularPercentual() { return Math.min(100, (this.#cumpridos * 100) / this.#meta); }
  estaCumprida() { return this.#cumpridos >= this.#meta; }
  paraJson() { // IExportavelJson
    return JSON.stringify({ metaMinutosSemana: this.#meta, minutosCumpridos: this.#cumpridos, percentual: this.calcularPercentual() });
  }
}

// ---------- Missão 3: Classe Abstrata e Herança ----------
class Usuario {
  #id; #nome; #email; #senha; // sem getter de senha, de propósito
  constructor(id, nome, email, senha) {
    if (new.target === Usuario) throw new Error("Usuario é abstrata: instancie Administrador, Responsavel ou Discente.");
    this.#id = id; this.#nome = nome; this.#email = email; this.#senha = senha;
  }
  getId() { return this.#id; }
  getNome() { return this.#nome; }
  getEmail() { return this.#email; }
  autenticar(senhaDigitada) { return senhaDigitada === this.#senha; }
  obterTipoPerfil() { throw new Error("Método abstrato"); }
  gerarPainelResumo() { throw new Error("Método abstrato"); }
}
class Administrador extends Usuario {
  #cargo;
  constructor(id, nome, email, senha, cargo) { super(id, nome, email, senha); this.#cargo = cargo; }
  getCargo() { return this.#cargo; }
  obterTipoPerfil() { return "Administrador"; }
  gerarPainelResumo() { return `Administrador ${this.getNome()} — ${this.#cargo}`; }
}
class Responsavel extends Usuario {
  #parentesco; #discentes = []; #metas = new Map();
  constructor(id, nome, email, senha, parentesco) { super(id, nome, email, senha); this.#parentesco = parentesco; }
  getParentesco() { return this.#parentesco; }
  obterTipoPerfil() { return "Responsável"; }
  gerarPainelResumo() { return `Responsável ${this.getNome()} (${this.#parentesco}) — acompanha ${this.#discentes.length} discente(s)`; }
  // ---------- Missão 7: Associação (Responsavel ——> Discente) ----------
  vincularDiscente(discente, meta) {
    if (!this.#discentes.includes(discente)) this.#discentes.push(discente);
    if (meta) this.#metas.set(discente, meta);
  }
  getDiscentes() { return [...this.#discentes]; }
  getMeta(discente) { return this.#metas.get(discente); }
}

// ---------- Missão 4: Polimorfismo Dinâmico ----------
class SessaoEstudo {
  #disciplina; #duracao;
  constructor(disciplina, duracaoMinutos) {
    if (new.target === SessaoEstudo) throw new Error("SessaoEstudo é abstrata.");
    this.#disciplina = disciplina; this.#duracao = duracaoMinutos;
  }
  getDisciplina() { return this.#disciplina; }
  getDuracaoMinutos() { return this.#duracao; }
  obterModalidade() { throw new Error("Método abstrato"); }
  calcularXp() { throw new Error("Método abstrato"); }
  gerarFeedback() {
    return `${this.obterModalidade()} em ${this.#disciplina.getNome()} (${this.#duracao} min) -> +${this.calcularXp()} XP`;
  }
  paraJson(discenteNome = "") { // IExportavelJson — formato esperado pelo backend
    return JSON.stringify({
      discenteNome, disciplina: this.#disciplina.getNome(), tipoModalidade: this.obterModalidade(),
      duracaoMinutos: this.#duracao, xpGanho: this.calcularXp(), resumoFeedback: this.gerarFeedback(),
    });
  }
}
class SessaoPomodoro extends SessaoEstudo {
  #ciclos;
  constructor(disciplina, minutos, ciclosCompletos) { super(disciplina, minutos); this.#ciclos = ciclosCompletos; }
  obterModalidade() { return "Pomodoro"; }
  calcularXp() { return this.getDuracaoMinutos() * 2 + this.#ciclos * 15; }
  gerarFeedback() { return `${super.gerarFeedback()} | ${this.#ciclos} ciclo(s) concluído(s)`; }
}
class SessaoExercicios extends SessaoEstudo {
  #total; #acertos;
  constructor(disciplina, minutos, totalQuestoes, acertos) { super(disciplina, minutos); this.#total = totalQuestoes; this.#acertos = acertos; }
  obterModalidade() { return "Exercicios"; }
  calcularXp() { return this.getDuracaoMinutos() + this.#acertos * 10; }
  gerarFeedback() {
    const pct = this.#total > 0 ? Math.round((this.#acertos * 100) / this.#total) : 0;
    return `${super.gerarFeedback()} | acertos: ${this.#acertos}/${this.#total} (${pct}%)`;
  }
}
class SessaoLeitura extends SessaoEstudo {
  #paginas; #resumo;
  constructor(disciplina, minutos, paginasLidas, fezResumo) { super(disciplina, minutos); this.#paginas = paginasLidas; this.#resumo = fezResumo; }
  obterModalidade() { return "Leitura"; }
  calcularXp() { return this.getDuracaoMinutos() + this.#paginas * 3 + (this.#resumo ? 25 : 0); }
}

// ---------- Missão 5: Polimorfismo Estático (sobrecarga simulada em JS) ----------
class Discente extends Usuario {
  #ra; #xp = 0; #historico = [];
  constructor(id, nome, email, senha, ra) { super(id, nome, email, senha); this.#ra = ra; }
  getRa() { return this.#ra; }
  getXpTotal() { return this.#xp; }
  adicionarXp(pontos) { if (pontos > 0) this.#xp += pontos; }
  getHistorico() { return [...this.#historico]; }
  obterTipoPerfil() { return "Discente"; }
  gerarPainelResumo() { return `Discente ${this.getNome()} (RA ${this.#ra}) — ${this.#xp} XP`; }
  registrarEstudo(...a) {
    if (a[0] instanceof SessaoEstudo) {                                   // Forma 1
      this.#historico.push(a[0]); this.adicionarXp(a[0].calcularXp()); return a[0];
    }
    if (a[0] instanceof Disciplina && a.length === 2) {                   // Forma 2: atalho rápido
      const [d, min] = a;
      return this.registrarEstudo(new SessaoPomodoro(d, min, Math.max(1, Math.floor(min / 25))));
    }
    if (a[0] instanceof Disciplina && a.length === 4) {                   // Forma 3: por horário
      const [d, ini, fim, pag] = a;
      return this.registrarEstudo(new SessaoLeitura(d, (fim - ini) * 60, pag, true));
    }
    throw new Error("registrarEstudo: combinação de argumentos inválida.");
  }
}

// ---------- Missão 6: Interfaces (INotificador) ----------
class NotificadorEmail {
  constructor(saida = console.log) { this.saida = saida; }
  obterCanal() { return "E-mail"; }
  enviarAlerta(dest, msg) { this.saida(`[E-mail] para ${dest}: ${msg}`); return true; }
}
class NotificadorWhatsApp {
  constructor(saida = console.log) { this.saida = saida; }
  obterCanal() { return "WhatsApp"; }
  enviarAlerta(dest, msg) { this.saida(`[WhatsApp] para ${dest}: ${msg}`); return true; }
}
class NotificadorPainel {
  constructor(saida = console.log) { this.saida = saida; }
  obterCanal() { return "Painel"; }
  enviarAlerta(dest, msg) { this.saida(`[Painel] ${dest}: ${msg}`); return true; }
}

// ---------- Missão 7: Agregação (TrilhaEstudo ◇── Disciplina) ----------
class TrilhaEstudo {
  #titulo; #admin; #disciplinas = [];
  constructor(titulo, administrador) { this.#titulo = titulo; this.#admin = administrador; }
  getTitulo() { return this.#titulo; }
  getAdministrador() { return this.#admin; }
  adicionarDisciplina(d) { if (!this.#disciplinas.includes(d)) this.#disciplinas.push(d); } // recebe pronta, de fora
  getDisciplinas() { return [...this.#disciplinas]; }
  calcularCargaHorariaTotal() { return this.#disciplinas.reduce((s, d) => s + d.getCargaHorariaSemanalHoras(), 0); }
}

// ---------- Missão 8: Composição (PlanoEstudo ◆── ItemCronograma) ----------
class ItemCronograma { // só PlanoEstudo cria; não é exportada no navegador de propósito
  constructor(dia, minutos) { this.dia = dia; this.minutos = minutos; Object.freeze(this); }
}
class PlanoEstudo {
  #itens = [];
  adicionarItem(diaSemana, minutos) { // recebe primitivos e faz o new aqui dentro
    if (!diaSemana || !(minutos > 0)) return false;
    this.#itens.push(new ItemCronograma(diaSemana, minutos)); return true;
  }
  listarItens() { return this.#itens.map(i => `${i.dia}: ${i.minutos} min`); } // nunca devolve a lista interna
  calcularTotalMinutos() { return this.#itens.reduce((s, i) => s + i.minutos, 0); }
}

// ---------- Missão 8: Dependência (sem campos de instância) ----------
class ServicoAlertaResponsavel {
  avaliarDiscente(discente, meta, responsavel, notificador) {
    const p = meta.calcularPercentual();
    const msg = p >= 100
      ? `Parabéns! ${discente.getNome()} atingiu a meta semanal.`
      : `${discente.getNome()} está em ${p.toFixed(0)}% da meta semanal.`;
    return notificador.enviarAlerta(responsavel.getEmail(), msg);
  }
}

if (typeof module !== "undefined") module.exports = {
  Disciplina, MetaEstudo, Usuario, Administrador, Responsavel, Discente, SessaoEstudo, SessaoPomodoro,
  SessaoExercicios, SessaoLeitura, NotificadorEmail, NotificadorWhatsApp, NotificadorPainel,
  TrilhaEstudo, PlanoEstudo, ServicoAlertaResponsavel, INotificador, IExportavelJson, cumpreContrato,
};
